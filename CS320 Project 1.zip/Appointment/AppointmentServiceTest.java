/* Author: Ryan Mackenzie
 * Date: 02/03/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a test case to ensure the AppointmentService class works properly.
 * 
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	   // Adding correctly formatted Appointments to Appointment array.
	   @Test
	   public void TestAddAppointment() {
	       AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));
	   }

	   // Attempting to add duplicate Appointment which should fail 
	   @Test
	   public void TestAddDuplicate() {
		   AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));
	       
	       assertEquals(false, appointmentService.AddAppointment(Appointment1));
	   }

	   // Deleting Appointments based off of the ID
	   @Test
	   public void TestAppointmentDelete() {
		   AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));

	       assertEquals(true, appointmentService.DeleteAppointment("1111111111"));
	       assertEquals(true, appointmentService.DeleteAppointment("3333333333"));
	   }

	   // Attempt to delete a non existent Appointment
	   @Test
	   public void TestAppointmentDeleteDoesNotExist() {
		   AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));

	       assertEquals(false, appointmentService.DeleteAppointment("4444444444"));
	       assertEquals(true, appointmentService.DeleteAppointment("3333333333"));
	   }

	   // Updating Appointments based off of ID
	   @Test
	   public void TestAppointmentUpdate() {
		   AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));

	       assertEquals(true, appointmentService.UpdateAppointment("1111111111", 2022, 6, 17, "Appointment description test"));
	       assertEquals(true, appointmentService.UpdateAppointment("3333333333", 2022, 6, 11, "Update appointment description test"));
	   }

	   // Attempting to update Appointment that does not exist
	   @Test
	   public void TestAppointmentUpdateDoesNotExist() {
		   AppointmentService appointmentService = new AppointmentService();
	       Appointment Appointment1 = new Appointment("1111111111", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment2 = new Appointment("2222222222", 2022, 6, 11, "Appointment description test");
	       Appointment Appointment3 = new Appointment("3333333333", 2022, 6, 11, "Appointment description test");
	       assertEquals(true, appointmentService.AddAppointment(Appointment1));
	       assertEquals(true, appointmentService.AddAppointment(Appointment2));
	       assertEquals(true, appointmentService.AddAppointment(Appointment3));

	       assertEquals(false, appointmentService.UpdateAppointment("4444444444", 2022, 6, 11, "Appointment description test"));
	   }

}
