/* Author: Ryan Mackenzie
 * Date: 02/03/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a class that defines the Appointment object and has
 * some error checking to ensure inputs are valid.
 * 
 */

import java.util.Date;

public class Appointment {
    /* Appointment fields */
	private String id;
	private String description;
	private Date today = new Date();
	private Date apt;

	/* Appointment constructor */
	public Appointment(String id, int year, int month, int day,  String description) {
		@SuppressWarnings("deprecation")
		Date dateInputTemp = new Date(year - 1900, month, day);
		System.out.println(dateInputTemp.toString() + " vs " + today.toString());
		System.out.println(today.before(dateInputTemp));
		
		if (id == null | id.length() > 10) {
			throw new IllegalArgumentException("Invalid id");
			
		} else if (today.after(dateInputTemp)) {
			throw new IllegalArgumentException("Date is in the past");
			
		} else if (description == null | description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
			
		} else {
			this.id = id;
			this.apt = dateInputTemp;
			this.description = description;
		}
		
	}
	
	// Getters
	public String GetID() {
		return id;
	}
	
	public Date GetDate() {
		return apt;
	}
	
	public String GetDescription() {
		return description;
	}
	
	// Setters
	public void SetDate(int year, int month, int day) {
		@SuppressWarnings("deprecation")
		Date dateInputTemp = new Date(year - 1900, month, day);
		if (dateInputTemp.before(today)) {
			throw new IllegalArgumentException("Date is in the past");
		} else {
			this.apt = dateInputTemp;	
		}
	}
	
	public void SetDescription(String description) {
		this.description = description;
	}
	
	@Override
	public boolean equals(Object appointment) {
		// Verifying object is not null and class is appointment
		if (appointment == this) {
			return true;
		}
		if (appointment == null) {
			return false;
		}
		if (getClass() != appointment.getClass()) {
			return false;
		}
		
		// Checking for matching or null ID
		Appointment other = (Appointment) appointment;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}
	
}
