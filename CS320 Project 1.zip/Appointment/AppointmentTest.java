/* Author: Ryan Mackenzie
 * Date: 02/03/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a test case to ensure the Appointment class works properly.
 * 
 */

import static org.junit.jupiter.api.Assertions.*;


import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	// Verifying that adding a properly formatted Appointment works.
	@Test
	void testAppointment() {
		@SuppressWarnings("deprecation")
		Date test = new Date(2022 - 1900, 6, 11);
		
		Appointment testAppointment = new Appointment("1234567890", 2022, 6, 11, "Appointment description test");
		assertTrue(testAppointment.GetID().equals("1234567890"));
		assertTrue(testAppointment.GetDate().equals(test));
		assertTrue(testAppointment.GetDescription().equals("Appointment description test"));
	}

	// Verifying exception is thrown if ID is not 10 characters.
	@Test
	void testIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", 2022, 6, 11, "Appointment description test");
		});		
	}
	
	// Verifying exception thrown when the date is before today. 
	@Test
	void testDateInPast() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", 2020, 6, 11, "Appointment date test");
		});		
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", 2022, 6, 11, 
					"Testing to verify that an illegal argument exception is thrown when the "
					+ "description of the appointment is longer than 50 characters. This description is too long on purpose.");
		});		
	}

}
