/* Author: Ryan Mackenzie
 * Date: 02/03/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a class that defines the Appointment object and has
 * some error checking to ensure inputs are valid.
 * 
 */

import java.util.ArrayList;

public class AppointmentService {
	/* Array to store multiple appointments */
	private ArrayList<Appointment> appointmentList;
	
	/* constructor */
	public AppointmentService() {
		appointmentList = new ArrayList<>();
	}
	
	public boolean AddAppointment(Appointment newAppointment) {
		boolean duplicate = false;
		for (Appointment listAppointment : appointmentList) {
			if (listAppointment.equals(newAppointment)) {
				duplicate = true;
			}
		}
		
		if (!duplicate) {
			appointmentList.add(newAppointment);
			System.out.println("New appointment added");
			return true;
		} else {
			System.out.println("Duplicate appointment");
			return false;
		}
	}
	
	public boolean DeleteAppointment(String id) {
		for (Appointment listAppointment : appointmentList) {
			if (listAppointment.GetID().equals(id)) {
				appointmentList.remove(listAppointment);
				System.out.println("Delete completed");
				return true;
			}
			
		}
		System.out.println("No appointment found");
		return false;
	}
	
	public boolean UpdateAppointment(String id, int year, int month, int day, String description) {
		for (Appointment listAppointment : appointmentList) {
			if (listAppointment.GetID().equals(id)) {
				if (month < 13 & month > 0 & day < 32 & day > 0) {
					listAppointment.SetDate(year, month, day);
				}
				if (!description.equals("") & description.length() > 50) {
					listAppointment.SetDescription(description);
				}
				System.out.println("Update complete");
				return true;
			}
		}
		System.out.println("No appointment found or invalid data entered");
		return false;
	}
}
