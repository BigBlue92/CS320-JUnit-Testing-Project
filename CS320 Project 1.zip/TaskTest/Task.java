/* Author: Ryan Mackenzie
 * Date: 01/28/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a class that defines the Task object and has
 * some error checking to ensure inputs are valid.
 * 
 */

public class Task {
    /* Task fields */
	private String id;
	private String name;
	private String description;

	/* Task constructor */
	public Task(String id, String name, String description) {
		if (id == null | id.length() > 10) {
			throw new IllegalArgumentException("Invalid id");
			
		} else if (name == null | name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
			
		} else if (description == null | description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
			
		} else {
			this.id = id;
			this.name = name;
			this.description = description;
		}
		
	}
	
	// Getters
	public String GetID() {
		return id;
	}
	
	public String GetName() {
		return name;
	}
	
	public String GetDescription() {
		return description;
	}
	
	// Setters
	public void SetName(String name) {
		this.name = name;
	}
	
	public void SetDescription(String description) {
		this.description = description;
	}
	
	@Override
	public boolean equals(Object task) {
		// Verifying object is not null and class is task
		if (task == this) {
			return true;
		}
		if (task == null) {
			return false;
		}
		if (getClass() != task.getClass()) {
			return false;
		}
		
		// Checking for matching or null ID
		Task other = (Task) task;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}
	
}
