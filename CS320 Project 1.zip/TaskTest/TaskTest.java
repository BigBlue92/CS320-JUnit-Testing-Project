/* Author: Ryan Mackenzie
 * Date: 01/28/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a test case to ensure the Task class works properly.
 * 
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	// Verifying that adding a properly formatted Task works.
	@Test
	void testTask() {
		Task testTask = new Task("1234567890", "Task name test", "Task description test");
		assertTrue(testTask.GetID().equals("1234567890"));
		assertTrue(testTask.GetName().equals("Task name test"));
		assertTrue(testTask.GetDescription().equals("Task description test"));
	}

	// Verifying exception is thrown if ID is not 10 characters.
	@Test
	void testIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678901", "Task name test", "Task description test");
		});		
	}
	
	// Verifying exception thrown when inputs are too long. 
	@Test
	void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Task name test to verify name cannot be longer than twenty characters", "Task description test");
		});		
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "Task name test", 
					"Testing to verify that an illegal argument exception is thrown when the "
					+ "description of the task is longer than 50 characters. This description is too long on purpose.");
		});		
	}

}
