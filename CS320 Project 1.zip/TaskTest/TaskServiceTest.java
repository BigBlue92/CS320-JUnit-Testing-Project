/* Author: Ryan Mackenzie
 * Date: 01/28/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a test case to ensure the TaskService class works properly.
 * 
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	   // Adding correctly formatted Tasks to Task array.
	   @Test
	   public void TestAddTask() {
	       TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));
	   }

	   // Attempting to add duplicate Task which should fail 
	   @Test
	   public void TestAddDuplicate() {
		   TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));
	       
	       assertEquals(false, taskService.AddTask(Task1));
	   }

	   // Deleting Tasks based off of the ID
	   @Test
	   public void TestTaskDelete() {
		   TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));

	       assertEquals(true, taskService.DeleteTask("1111111111"));
	       assertEquals(true, taskService.DeleteTask("3333333333"));
	   }

	   // Attempt to delete a non existent Task
	   @Test
	   public void TestTaskDeleteDoesNotExist() {
		   TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));

	       assertEquals(false, taskService.DeleteTask("4444444444"));
	       assertEquals(true, taskService.DeleteTask("3333333333"));
	   }

	   // Updating Tasks based off of ID
	   @Test
	   public void TestTaskUpdate() {
		   TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));

	       assertEquals(true, taskService.UpdateTask("1111111111", "update name test", "Task description test"));
	       assertEquals(true, taskService.UpdateTask("3333333333", "Task name test", "Update task description test"));
	   }

	   // Attempting to update Task that does not exist
	   @Test
	   public void TestTaskUpdateDoesNotExist() {
		   TaskService taskService = new TaskService();
	       Task Task1 = new Task("1111111111", "Task name test", "Task description test");
	       Task Task2 = new Task("2222222222", "Task name test", "Task description test");
	       Task Task3 = new Task("3333333333", "Task name test", "Task description test");
	       assertEquals(true, taskService.AddTask(Task1));
	       assertEquals(true, taskService.AddTask(Task2));
	       assertEquals(true, taskService.AddTask(Task3));

	       assertEquals(false, taskService.UpdateTask("4444444444", "Update non existent task", "Task description test"));
	   }

}
