/* Author: Ryan Mackenzie
 * Date: 01/28/2022
 * Class: CS320-T3687
 * Version: 1.0
 * 
 * This is a class that defines the Task object and has
 * some error checking to ensure inputs are valid.
 * 
 */

import java.util.ArrayList;

public class TaskService {
	/* Array to store multiple tasks */
	private ArrayList<Task> taskList;
	
	/* constructor */
	public TaskService() {
		taskList = new ArrayList<>();
	}
	
	public boolean AddTask(Task newTask) {
		boolean duplicate = false;
		for (Task listTask : taskList) {
			if (listTask.equals(newTask)) {
				duplicate = true;
			}
		}
		
		if (!duplicate) {
			taskList.add(newTask);
			System.out.println("New task added");
			return true;
		} else {
			System.out.println("Duplicate task");
			return false;
		}
	}
	
	public boolean DeleteTask(String id) {
		for (Task listTask : taskList) {
			if (listTask.GetID().equals(id)) {
				taskList.remove(listTask);
				System.out.println("Delete completed");
				return true;
			}
			
		}
		System.out.println("No task found");
		return false;
	}
	
	public boolean UpdateTask(String id, String name, String description) {
		for (Task listTask : taskList) {
			if (listTask.GetID().equals(id)) {
				if (!name.equals("") & name.length() > 20) {
					listTask.SetName(name);
				}
				if (!description.equals("") & description.length() > 50) {
					listTask.SetDescription(description);
				}
				System.out.println("Update complete");
				return true;
			}
		}
		System.out.println("No task found or invalid data entered");
		return false;
	}
}
